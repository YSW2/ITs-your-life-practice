package org.scoula.weather.dto;

import lombok.Data;

@Data
public class Clouds{
	private int all;
}