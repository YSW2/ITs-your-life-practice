package ch12.sec03.practice1.ex07;

public record Member(String id, String name, int age) {
}
